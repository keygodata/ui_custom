<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>{$_title} - {$_c['CompanyName']}</title>
    <link rel="shortcut icon" href="{$app_url}/ui/ui/images/logo.png" type="image/x-icon" />

    <script>
        var appUrl = '{$app_url}';
    </script>

    <!-- ==== Framework lama tetap dimuat agar halaman internal tidak rusak ==== -->
    <link rel="stylesheet" href="{$app_url}/ui/ui/styles/bootstrap.min.css">
    <link rel="stylesheet" href="{$app_url}/ui/ui/fonts/ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="{$app_url}/ui/ui/fonts/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="{$app_url}/ui/ui/styles/select2.min.css" />
    <link rel="stylesheet" href="{$app_url}/ui/ui/styles/select2-bootstrap.min.css" />
    <link rel="stylesheet" href="{$app_url}/ui/ui/styles/sweetalert2.min.css" />
    <link rel="stylesheet" href="{$app_url}/ui/ui/summernote/summernote.min.css" />
    <link rel="stylesheet" href="{$app_url}/ui/ui/styles/phpnuxbill.css?2025.2.4" />
    <link rel="stylesheet" href="{$app_url}/ui/ui/styles/7.css" />

    <script src="{$app_url}/ui/ui/scripts/sweetalert2.all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.5.1/dist/chart.min.js"></script>

    <!-- ============================================================
         MODERN THEME — RLradius-inspired
         ============================================================ -->

    <style>
        :root {
            --rl-sidebar-w: 250px;
            --rl-sidebar-w-mini: 62px;
            --rl-topbar-h: 56px;
            --rl-sidebar-bg: #1c2b4a;
            --rl-sidebar-bg-2: #16233d;
            --rl-sidebar-hover: #253859;
            --rl-sidebar-active: #0d6efd;
            --rl-sidebar-text: #b6c2d9;
            --rl-sidebar-text-active: #ffffff;
            --rl-topbar-bg: #ffffff;
            --rl-content-bg: #f4f6fb;
            --rl-text: #1e293b;
            --rl-text-muted: #64748b;
            --rl-text-light: #94a3b8;
            --rl-border: #e6ebf2;
            --rl-primary: #0d6efd;
            --rl-success: #198754;
            --rl-warning: #d97706;
            --rl-danger: #dc3545;
            --rl-info: #0aa2c0;
            --rl-shadow: 0 1px 3px rgba(15, 23, 42, .06), 0 1px 2px rgba(15, 23, 42, .04);
        }

        /* ---------- Reset & Body ---------- */
        html, body { height: 100%; }
        body.rl-body {
            background: var(--rl-content-bg) !important;
            color: var(--rl-text);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            font-size: 13px;
            overflow-x: hidden;
        }
        body.rl-body.no-scroll { overflow: hidden; }

        /* ---------- Wrapper ---------- */
        .rl-wrapper { min-height: 100vh; padding-top: var(--rl-topbar-h); }

        /* ============================================================
           SIDEBAR
           ============================================================ */
        .rl-sidebar {
            position: fixed;
            top: var(--rl-topbar-h);
            left: 0;
            bottom: 0;
            width: var(--rl-sidebar-w);
            background: var(--rl-sidebar-bg);
            color: var(--rl-sidebar-text);
            overflow-y: auto;
            overflow-x: hidden;
            z-index: 1030;
            transition: width .25s ease, transform .25s ease;
            scrollbar-width: thin;
            scrollbar-color: #2c4468 transparent;
        }
        .rl-sidebar::-webkit-scrollbar { width: 6px; }
        .rl-sidebar::-webkit-scrollbar-thumb { background: #2c4468; border-radius: 3px; }

        .rl-sidebar-brand {
            padding: 14px 18px;
            border-bottom: 1px solid rgba(255,255,255,.06);
            display: flex;
            align-items: center;
            gap: 10px;
            color: #fff;
            font-weight: 700;
            letter-spacing: .02em;
            white-space: nowrap;
            overflow: hidden;
        }
        .rl-sidebar-brand i {
            font-size: 22px;
            color: var(--rl-sidebar-active);
            flex-shrink: 0;
        }
        .rl-sidebar-brand span { transition: opacity .2s ease; }

        .rl-nav { list-style: none; padding: 8px 0; margin: 0; }
        .rl-nav-item { position: relative; }

        .rl-nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 18px;
            color: var(--rl-sidebar-text) !important;
            text-decoration: none !important;
            font-size: 13px;
            font-weight: 500;
            border-left: 3px solid transparent;
            transition: background .18s ease, color .18s ease, border-color .18s ease;
            white-space: nowrap;
            overflow: hidden;
        }
        .rl-nav-link > i:first-child {
            font-size: 16px;
            width: 20px;
            text-align: center;
            flex-shrink: 0;
        }
        .rl-nav-link:hover {
            background: var(--rl-sidebar-hover);
            color: var(--rl-sidebar-text-active) !important;
        }
        .rl-nav-item.active > .rl-nav-link {
            background: var(--rl-sidebar-hover);
            color: var(--rl-sidebar-text-active) !important;
            border-left-color: var(--rl-sidebar-active);
        }

        /* Arrow untuk submenu */
        .rl-nav-link .rl-arrow {
            margin-left: auto;
            font-size: 11px;
            transition: transform .2s ease;
            opacity: .7;
        }
        .rl-nav-item.rl-open > .rl-nav-link .rl-arrow {
            transform: rotate(90deg);
        }

        /* Submenu */
        .rl-submenu {
            list-style: none;
            padding: 0;
            margin: 0;
            max-height: 0;
            overflow: hidden;
            background: var(--rl-sidebar-bg-2);
            transition: max-height .3s ease;
        }
        .rl-nav-item.rl-open > .rl-submenu { max-height: 600px; }
        .rl-submenu .rl-sub-link {
            display: block;
            padding: 8px 18px 8px 50px;
            font-size: 12.5px;
            color: var(--rl-sidebar-text) !important;
            text-decoration: none !important;
            border-left: 3px solid transparent;
            transition: background .15s ease, color .15s ease;
            position: relative;
        }
        .rl-submenu .rl-sub-link::before {
            content: '';
            position: absolute;
            left: 30px;
            top: 50%;
            width: 4px; height: 4px;
            border-radius: 50%;
            background: currentColor;
            opacity: .4;
            transform: translateY(-50%);
        }
        .rl-submenu .rl-sub-link:hover,
        .rl-submenu .rl-sub-link.active {
            background: rgba(255,255,255,.04);
            color: #fff !important;
            border-left-color: var(--rl-sidebar-active);
        }

        /* ---------- Sidebar Mini (collapsed) ---------- */
        body.rl-mini .rl-sidebar { width: var(--rl-sidebar-w-mini); }
        body.rl-mini .rl-sidebar-brand span,
        body.rl-mini .rl-nav-link span,
        body.rl-mini .rl-nav-link .rl-arrow { display: none; }
        body.rl-mini .rl-nav-link { justify-content: center; padding: 12px 0; }
        body.rl-mini .rl-nav-link > i:first-child { font-size: 18px; }
        body.rl-mini .rl-submenu { display: none !important; }
        body.rl-mini .rl-content,
        body.rl-mini .rl-topbar-brand,
        body.rl-mini .rl-footer {
            margin-left: var(--rl-sidebar-w-mini) !important;
        }

        /* ============================================================
           TOPBAR
           ============================================================ */
        .rl-topbar {
            position: fixed;
            top: 0; left: 0; right: 0;
            height: var(--rl-topbar-h);
            background: var(--rl-topbar-bg);
            border-bottom: 1px solid var(--rl-border);
            display: flex;
            align-items: center;
            z-index: 1040;
            box-shadow: var(--rl-shadow);
        }
        .rl-topbar-brand {
            width: var(--rl-sidebar-w);
            height: 100%;
            padding: 0 18px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 700;
            color: var(--rl-text) !important;
            text-decoration: none !important;
            border-right: 1px solid var(--rl-border);
            font-size: 15px;
            transition: width .25s ease;
            white-space: nowrap;
            overflow: hidden;
        }
        .rl-topbar-brand img { height: 30px; }
        .rl-topbar-brand i { color: var(--rl-primary); font-size: 20px; }

        .rl-topbar-main {
            flex: 1;
            display: flex;
            align-items: center;
            padding: 0 16px;
            gap: 12px;
            min-width: 0;
        }
        .rl-sidebar-toggle {
            background: transparent;
            border: 0;
            color: var(--rl-text);
            font-size: 18px;
            padding: 6px 10px;
            border-radius: 6px;
            cursor: pointer;
            flex-shrink: 0;
        }
        .rl-sidebar-toggle:hover { background: rgba(13,110,253,.08); color: var(--rl-primary); }

        .rl-server-info {
            display: flex;
            align-items: center;
            gap: 16px;
            font-size: 12px;
            color: var(--rl-text-muted);
            font-weight: 500;
        }
        .rl-server-info .rl-meta-item {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            white-space: nowrap;
        }
        .rl-server-info i { color: var(--rl-text-light); }

        .rl-topbar-actions {
            display: flex;
            align-items: center;
            gap: 2px;
            margin-left: auto;
        }
        .rl-icon-btn {
            width: 38px; height: 38px;
            border-radius: 8px;
            background: transparent;
            border: 0;
            color: var(--rl-text-muted);
            font-size: 17px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: background .15s ease, color .15s ease;
            position: relative;
        }
        .rl-icon-btn:hover { background: rgba(13,110,253,.08); color: var(--rl-primary); }
        .rl-icon-btn .rl-badge {
            position: absolute;
            top: 4px; right: 4px;
            background: var(--rl-danger);
            color: #fff;
            font-size: 9px;
            font-weight: 700;
            padding: 1px 5px;
            border-radius: 999px;
            line-height: 1.4;
        }

        .rl-user-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 5px 10px 5px 5px;
            border-radius: 999px;
            border: 1px solid var(--rl-border);
            background: #fff;
            color: var(--rl-text);
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: border-color .15s ease, box-shadow .15s ease;
            max-width: 190px;
        }
        .rl-user-btn:hover { border-color: var(--rl-primary); box-shadow: 0 0 0 3px rgba(13,110,253,.08); }
        .rl-user-btn img {
            width: 28px; height: 28px;
            border-radius: 50%;
            object-fit: cover;
            flex-shrink: 0;
        }
        .rl-user-btn .rl-user-name {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 110px;
        }
        .rl-user-btn i { color: var(--rl-text-light); font-size: 11px; }

        .rl-dropdown {
            position: absolute;
            top: calc(var(--rl-topbar-h) - 4px);
            right: 12px;
            min-width: 230px;
            background: #fff;
            border: 1px solid var(--rl-border);
            border-radius: 10px;
            box-shadow: 0 10px 25px rgba(15,23,42,.12);
            padding: 6px;
            z-index: 1050;
            display: none;
        }
        .rl-dropdown.rl-show { display: block; animation: rlFade .15s ease; }
        @keyframes rlFade { from { opacity: 0; transform: translateY(-4px); } to { opacity: 1; transform: translateY(0); } }

        .rl-dropdown a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 9px 12px;
            color: var(--rl-text) !important;
            text-decoration: none !important;
            font-size: 13px;
            border-radius: 6px;
            transition: background .12s ease;
        }
        .rl-dropdown a:hover { background: rgba(13,110,253,.08); color: var(--rl-primary) !important; }
        .rl-dropdown a.rl-danger { color: var(--rl-danger) !important; }
        .rl-dropdown a.rl-danger:hover { background: rgba(220,53,69,.08); }
        .rl-dropdown .rl-divider { height: 1px; background: var(--rl-border); margin: 6px 4px; }
        .rl-dropdown-head {
            padding: 10px 12px;
            border-bottom: 1px solid var(--rl-border);
            margin-bottom: 6px;
        }
        .rl-dropdown-head strong { display: block; font-size: 13px; color: var(--rl-text); }
        .rl-dropdown-head small  { color: var(--rl-text-muted); font-size: 11px; }

        /* ============================================================
           MAIN CONTENT
           ============================================================ */
        .rl-content {
            margin-left: var(--rl-sidebar-w);
            transition: margin-left .25s ease;
            min-height: calc(100vh - var(--rl-topbar-h));
            display: flex;
            flex-direction: column;
        }
        .rl-content-header {
            background: #fff;
            border-bottom: 1px solid var(--rl-border);
            padding: 18px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 10px;
        }
        .rl-content-header h1 {
            font-size: 18px;
            font-weight: 700;
            color: var(--rl-text);
            margin: 0;
            text-transform: uppercase;
            letter-spacing: .01em;
        }
        .rl-content-header h1 i { color: var(--rl-primary); margin-right: 8px; }
        .rl-content-body {
            padding: 20px 24px;
            flex: 1;
        }

        /* Fix AdminLTE content wrapper yang lama */
        .content-wrapper { background: transparent !important; margin: 0 !important; min-height: auto !important; }
        .content-header { display: none !important; }
        .content { padding: 0 !important; }

        /* ============================================================
           FOOTER
           ============================================================ */
        .rl-footer {
            margin-left: 0;
            padding: 14px 24px;
            background: #fff;
            border-top: 1px solid var(--rl-border);
            font-size: 12px;
            color: var(--rl-text-muted);
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 8px;
        }

        /* ============================================================
           SEARCH OVERLAY
           ============================================================ */
        .rl-search-overlay {
            position: fixed;
            inset: 0;
            background: rgba(15,23,42,.55);
            backdrop-filter: blur(4px);
            z-index: 2000;
            display: none;
            align-items: flex-start;
            justify-content: center;
            padding-top: 10vh;
        }
        .rl-search-overlay.rl-open { display: flex; }
        .rl-search-box {
            background: #fff;
            border-radius: 12px;
            width: min(640px, 92vw);
            overflow: hidden;
            box-shadow: 0 25px 60px rgba(15,23,42,.3);
        }
        .rl-search-box input {
            width: 100%;
            border: 0;
            padding: 18px 22px;
            font-size: 16px;
            outline: none;
            border-bottom: 1px solid var(--rl-border);
        }
        .rl-search-results {
            max-height: 55vh;
            overflow-y: auto;
        }
        .rl-search-results .rl-result {
            display: block;
            padding: 12px 22px;
            border-bottom: 1px solid var(--rl-border);
            color: var(--rl-text) !important;
            text-decoration: none !important;
            font-size: 13px;
            transition: background .12s ease;
        }
        .rl-search-results .rl-result:hover { background: rgba(13,110,253,.06); }
        .rl-search-box .rl-search-foot {
            padding: 10px 22px;
            background: #f8fafc;
            text-align: right;
        }
        .rl-search-box .rl-search-foot button {
            background: transparent;
            border: 0;
            color: var(--rl-text-muted);
            font-size: 12px;
            cursor: pointer;
        }

        /* ============================================================
           MAINTENANCE BAR
           ============================================================ */
        .rl-maintenance {
            background: #dc3545;
            color: #fff;
            padding: 8px 24px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            flex-wrap: wrap;
        }
        .rl-maintenance a { color: #fff; text-decoration: underline; font-weight: 700; }

        /* ============================================================
           OVERLAY (mobile sidebar)
           ============================================================ */
        .rl-overlay {
            position: fixed;
            inset: 0;
            background: rgba(15,23,42,.5);
            z-index: 1029;
            display: none;
        }
        .rl-overlay.rl-show { display: block; }

        /* ============================================================
           RESPONSIVE
           ============================================================ */
        @media (max-width: 991px) {
            .rl-sidebar {
                transform: translateX(-100%);
                width: var(--rl-sidebar-w);
            }
            body.rl-mobile-open .rl-sidebar { transform: translateX(0); }
            .rl-content, .rl-topbar-brand, .rl-footer { margin-left: 0 !important; }
            .rl-topbar-brand { width: auto; border-right: 0; padding: 0 12px; }
            .rl-content-header { padding: 14px 16px; }
            .rl-content-body { padding: 14px 16px; }
            .rl-server-info { display: none !important; }
        }
        @media (max-width: 575px) {
            .rl-content-header h1 { font-size: 15px; }
            .rl-user-btn .rl-user-name { display: none; }
        }

        /* Dark mode */
        body.rl-dark {
            --rl-content-bg: #0f172a;
            --rl-text: #e2e8f0;
            --rl-text-muted: #94a3b8;
            --rl-text-light: #64748b;
            --rl-border: #1e293b;
            --rl-topbar-bg: #16233d;
        }
        body.rl-dark .rl-topbar-brand,
        body.rl-dark .rl-content-header,
        body.rl-dark .rl-footer { background: #16233d; color: #e2e8f0; }
        body.rl-dark .rl-user-btn { background: #1e293b; color: #e2e8f0; border-color: #334155; }
        body.rl-dark .rl-dropdown { background: #1e293b; border-color: #334155; }
        body.rl-dark .rl-dropdown a { color: #e2e8f0 !important; }
        body.rl-dark .rl-search-box { background: #1e293b; color: #e2e8f0; }
        body.rl-dark .rl-search-box input { background: #1e293b; color: #e2e8f0; }
        body.rl-dark .card, body.rl-dark .box { background: #1e293b; border-color: #334155; color: #e2e8f0; }
		
		
		
		
/* ============================================================
   FALLBACK: Normalisasi menu plugin yang markup-nya tidak konsisten
   Berlaku untuk <li> dan <a> di dalam sidebar apapun class-nya
   ============================================================ */

/* Semua <li> di dalam submenu — berapapun class-nya */
.rl-submenu > li {
    list-style: none;
    position: relative;
}
.rl-submenu > li > a {
    display: block !important;
    padding: 8px 18px 8px 50px !important;
    font-size: 12.5px !important;
    color: var(--rl-sidebar-text) !important;
    text-decoration: none !important;
    border-left: 3px solid transparent;
    background: transparent !important;
    transition: background .15s ease, color .15s ease, border-color .15s ease;
    position: relative;
    line-height: 1.4;
    white-space: normal;
}
.rl-submenu > li > a::before {
    content: '';
    position: absolute;
    left: 30px;
    top: 50%;
    width: 4px;
    height: 4px;
    border-radius: 50%;
    background: currentColor;
    opacity: .4;
    transform: translateY(-50%);
}
.rl-submenu > li > a:hover,
.rl-submenu > li > a.active,
.rl-submenu > li.active > a {
    background: rgba(255,255,255,.04) !important;
    color: #fff !important;
    border-left-color: var(--rl-sidebar-active);
}

/* Kalau plugin inject <a> langsung ke <ul> tanpa <li> */
.rl-submenu > a {
    display: block !important;
    padding: 8px 18px 8px 50px !important;
    font-size: 12.5px !important;
    color: var(--rl-sidebar-text) !important;
    text-decoration: none !important;
    border-left: 3px solid transparent;
    position: relative;
}
.rl-submenu > a::before {
    content: '';
    position: absolute;
    left: 30px;
    top: 50%;
    width: 4px;
    height: 4px;
    border-radius: 50%;
    background: currentColor;
    opacity: .4;
    transform: translateY(-50%);
}
.rl-submenu > a:hover {
    background: rgba(255,255,255,.04) !important;
    color: #fff !important;
    border-left-color: var(--rl-sidebar-active);
}

/* Kalau plugin inject teks / <i> langsung ke <ul> (bukan dibungkus <a>/<li>) */
.rl-submenu > i,
.rl-submenu > span {
    display: block;
    padding: 8px 18px 8px 50px;
    font-size: 12.5px;
    color: var(--rl-sidebar-text);
    font-style: normal;
}

/* ============================================================
   OVERRIDE: Netralkan class Bootstrap 3/4/5 yang dibawa plugin
   ============================================================ */

/* Bootstrap 4/5 nav-item & nav-link */
.rl-submenu .nav-item,
.rl-nav .nav-item {
    list-style: none !important;
    margin: 0 !important;
    padding: 0 !important;
    width: 100% !important;
}
.rl-submenu .nav-link,
.rl-nav .nav-link {
    display: block !important;
    padding: 8px 18px 8px 50px !important;
    margin: 0 !important;
    border-radius: 0 !important;
    font-size: 12.5px !important;
    color: var(--rl-sidebar-text) !important;
    text-decoration: none !important;
    background: transparent !important;
    border: 0 !important;
    border-left: 3px solid transparent !important;
}
.rl-submenu .nav-link:hover,
.rl-nav .nav-link:hover {
    background: rgba(255,255,255,.04) !important;
    color: #fff !important;
    border-left-color: var(--rl-sidebar-active) !important;
}

/* ============================================================
   OVERRIDE: Class AdminLTE lama (sidebar-menu, treeview-menu)
   Kadang plugin inject pakai class lama PHPNuxBill
   ============================================================ */
.rl-submenu .sidebar-menu,
.rl-submenu .treeview-menu,
.rl-nav .sidebar-menu,
.rl-nav .treeview-menu {
    background: transparent !important;
    padding: 0 !important;
    margin: 0 !important;
    list-style: none !important;
}

/* ============================================================
   ICON FIX: Ikon plugin kadang terlalu besar/kecil
   ============================================================ */
.rl-submenu > li > a > i,
.rl-submenu .nav-link > i,
.rl-submenu > a > i {
    margin-right: 8px;
    font-size: 13px;
    width: 15px;
    text-align: center;
    vertical-align: middle;
    color: inherit;
}

/* Badge / label plugin */
.rl-submenu .badge,
.rl-submenu .label {
    float: right;
    font-size: 10px;
    padding: 3px 7px;
    border-radius: 999px;
    line-height: 1;
    margin-top: 2px;
}

/* ============================================================
   RESPONSIVE: pastikan ikon & teks tetap rapi di mini sidebar
   ============================================================ */
body.rl-mini .rl-submenu .nav-link,
body.rl-mini .rl-submenu > li > a {
    padding: 8px 12px !important;
}	


/* ============================================================
   UNIVERSAL SIDEBAR NORMALIZATION
   Menangkap menu plugin dengan markup apapun
   ============================================================ */

/* Reset semua UL/LI di sidebar */
#rlSidebar ul {
    list-style: none !important;
    padding: 0 !important;
    margin: 0 !important;
}
#rlSidebar li {
    list-style: none !important;
    padding: 0 !important;
    margin: 0 !important;
    position: relative;
}

/* Semua <a> di dalam sidebar — base style (top level) */
#rlNav a,
#rlSidebar .rl-submenu a,
#rlSidebar .treeview-menu a,
#rlSidebar .nav-item a {
    display: flex !important;
    align-items: center;
    gap: 12px;
    padding: 10px 18px !important;
    color: var(--rl-sidebar-text) !important;
    text-decoration: none !important;
    font-size: 13px !important;
    font-weight: 500;
    background: transparent !important;
    border-left: 3px solid transparent !important;
    border-right: 0 !important;
    border-top: 0 !important;
    border-bottom: 0 !important;
    border-radius: 0 !important;
    transition: background .15s, color .15s, border-color .15s;
    line-height: 1.4;
    white-space: normal;
    overflow-wrap: break-word;
    box-shadow: none !important;
}

#rlNav a:hover,
#rlSidebar .rl-submenu a:hover,
#rlSidebar .treeview-menu a:hover,
#rlSidebar .nav-item a:hover {
    background: var(--rl-sidebar-hover) !important;
    color: #fff !important;
}

/* Active state */
#rlSidebar li.active > a,
#rlSidebar li.menu-open > a,
#rlSidebar li.open > a,
#rlSidebar a.active {
    background: var(--rl-sidebar-hover) !important;
    color: #fff !important;
    border-left-color: var(--rl-sidebar-active) !important;
}

/* ============================================================
   SUBMENU — targetkan berdasarkan kedalaman UL, bukan class
   Semua <a> yang berada di dalam <ul> bersarang otomatis jadi submenu
   ============================================================ */
#rlNav ul a,
#rlSidebar .rl-submenu a,
#rlSidebar .treeview-menu a {
    padding: 8px 18px 8px 50px !important;
    font-size: 12.5px !important;
    font-weight: 500;
}

#rlNav ul a::before,
#rlSidebar .rl-submenu a::before,
#rlSidebar .treeview-menu a::before {
    content: '';
    position: absolute;
    left: 30px;
    top: 50%;
    width: 4px;
    height: 4px;
    border-radius: 50%;
    background: currentColor;
    opacity: .4;
    transform: translateY(-50%);
}

#rlNav ul a:hover,
#rlSidebar .rl-submenu a:hover,
#rlSidebar .treeview-menu a:hover {
    background: rgba(255,255,255,.04) !important;
    color: #fff !important;
    border-left-color: var(--rl-sidebar-active) !important;
}

/* ============================================================
   IKON — glyphicon, fa, ion, apapun classnya
   ============================================================ */
#rlSidebar a > i,
#rlSidebar a > .glyphicon,
#rlSidebar a > span.glyphicon,
#rlSidebar a > img {
    font-size: 15px !important;
    width: 20px !important;
    min-width: 20px !important;
    text-align: center !important;
    flex-shrink: 0;
    margin: 0 !important;
    top: 0 !important;
    color: inherit !important;
    display: inline-block;
}

/* ============================================================
   NETRALKAN CLASS ADMINLTE LAMA yang bikin berantakan
   ============================================================ */
#rlSidebar .pull-right-container,
#rlSidebar .pull-right,
#rlSidebar a > .fa-angle-left,
#rlSidebar a > .fa-angle-down,
#rlSidebar a > .fa-angle-right.pull-right {
    display: none !important;
}

/* ============================================================
   ARROW OTOMATIS — hanya untuk <li> yang punya <ul> anak
   ============================================================ */
#rlSidebar li > ul {
    max-height: 0;
    overflow: hidden;
    transition: max-height .3s ease;
    background: var(--rl-sidebar-bg-2);
}
#rlSidebar li.rl-open > ul,
#rlSidebar li.open > ul,
#rlSidebar li.menu-open > ul,
#rlSidebar li.active > ul {
    max-height: 800px;
}

/* Arrow ::after untuk parent menu */
#rlSidebar li > ul + a::after,
#rlSidebar li:has(> ul) > a::after {
    content: '\f105';
    font-family: 'FontAwesome';
    margin-left: auto;
    font-size: 12px;
    opacity: .6;
    transition: transform .2s ease;
}
#rlSidebar li.rl-open > a::after,
#rlSidebar li.open > a::after,
#rlSidebar li.menu-open > a::after,
#rlSidebar li.active > a::after {
    transform: rotate(90deg);
}

/* ============================================================
   BADGE / LABEL
   ============================================================ */
#rlSidebar .badge,
#rlSidebar .label {
    margin-left: auto;
    font-size: 10px !important;
    padding: 3px 7px;
    border-radius: 999px;
    line-height: 1;
    font-weight: 700;
}

/* ============================================================
   MODE MINI — semua menu collapse rapi
   ============================================================ */
body.rl-mini #rlSidebar a {
    justify-content: center;
    padding: 12px 0 !important;
}
body.rl-mini #rlSidebar a > span:not(.badge):not(.label) {
    display: none !important;
}
body.rl-mini #rlSidebar li > ul {
    display: none !important;
}
body.rl-mini #rlSidebar a::after {
    display: none !important;
}	
    </style>




    {if isset($xheader)}{$xheader}{/if}
</head>

<body class="rl-body {if $_kolaps}rl-mini{/if}">

<div class="rl-wrapper">

    <!-- ============================= TOPBAR ============================= -->
    <header class="rl-topbar">
        <a href="{Text::url('dashboard')}" class="rl-topbar-brand">
            <img src="{$app_url}/ui/ui/images/logo.png" onerror="this.style.display='none'">
            <span class="hidden-xs">{$_c['CompanyName']}</span>
        </a>

        <div class="rl-topbar-main">
            <button type="button" class="rl-sidebar-toggle" id="rlSidebarToggle">
                <i class="fa fa-bars"></i>
            </button>

            <div class="rl-server-info">
                <span class="rl-meta-item">
                    <i class="fa fa-user-circle"></i>
                    <span>{$_admin['fullname']|upper}</span>
                </span>
                <span class="rl-meta-item">
                    <i class="fa fa-clock-o"></i>
                    <span>{Lang::T('Waktu Server')} :
                        <span id="servertime">{$smarty.now|date_format:'%H:%M:%S'}</span>
                    </span>
                </span>
            </div>

            <div class="rl-topbar-actions">
                <button type="button" class="rl-icon-btn" id="rlSearchBtn" title="{Lang::T('Search Users')}">
                    <i class="fa fa-search"></i>
                </button>
                <button type="button" class="rl-icon-btn" id="rlThemeBtn" title="Toggle theme">
                    <i class="fa fa-moon-o"></i>
                </button>
                <button type="button" class="rl-icon-btn" id="rlUserBtn" title="Account">
                    <i class="fa fa-user-o"></i>
                </button>
                <button type="button" class="rl-user-btn" id="rlUserDropdownBtn">
                    <img src="{$app_url}/{$UPLOAD_PATH}{$_admin['photo']}.thumb.jpg"
                         onerror="this.src='{$app_url}/{$UPLOAD_PATH}/admin.default.png'" alt="Avatar">
                    <span class="rl-user-name hidden-xs">{$_admin['fullname']}</span>
                    <i class="fa fa-angle-down"></i>
                </button>
            </div>
        </div>
    </header>

    <!-- User dropdown -->
    <div class="rl-dropdown" id="rlUserDropdown">
        <div class="rl-dropdown-head">
            <strong>{$_admin['fullname']}</strong>
            <small>{Lang::T($_admin['user_type'])}</small>
        </div>
        <a href="{Text::url('settings/change-password')}">
            <i class="fa fa-key"></i> {Lang::T('Change Password')}
        </a>
        <a href="{Text::url('settings/users-view/', $_admin['id'])}">
            <i class="fa fa-user"></i> {Lang::T('My Account')}
        </a>
        <div class="rl-divider"></div>
        <a href="{Text::url('logout')}" class="rl-danger">
            <i class="fa fa-power-off"></i> {Lang::T('Logout')}
        </a>
    </div>

    <!-- ============================= SIDEBAR ============================= -->
    <aside class="rl-sidebar" id="rlSidebar">
        <div class="rl-sidebar-brand">
            <i class="ion ion-monitor"></i>
            <span>{Lang::T('Menu Utama')}</span>
        </div>

        <ul class="rl-nav" id="rlNav">
            <!-- Dashboard -->
            <li class="rl-nav-item {if $_system_menu eq 'dashboard'}active{/if}">
                <a href="{Text::url('dashboard')}" class="rl-nav-link">
                    <i class="ion ion-monitor"></i>
                    <span>{Lang::T('Dashboard')}</span>
                </a>
            </li>
            {$_MENU_AFTER_DASHBOARD}

            <!-- Customer -->
            <li class="rl-nav-item {if $_system_menu eq 'customers'}active{/if}">
                <a href="{Text::url('customers')}" class="rl-nav-link">
                    <i class="fa fa-user"></i>
                    <span>{Lang::T('Customer')}</span>
                </a>
            </li>
            {$_MENU_AFTER_CUSTOMERS}

            <!-- Services (treeview) -->
            {if !in_array($_admin['user_type'],['Report'])}
            <li class="rl-nav-item {if $_routes[0] eq 'plan' || $_routes[0] eq 'coupons'}active rl-open{/if}">
                <a href="javascript:void(0);" class="rl-nav-link">
                    <i class="fa fa-ticket"></i>
                    <span>{Lang::T('Services')}</span>
                    <i class="fa fa-angle-right rl-arrow"></i>
                </a>
                <ul class="rl-submenu">
                    <li><a href="{Text::url('plan/list')}" class="rl-sub-link {if $_routes[1] eq 'list'}active{/if}">{Lang::T('Active Customers')}</a></li>
                    {if $_c['disable_voucher'] != 'yes'}
                        <li><a href="{Text::url('plan/refill')}" class="rl-sub-link {if $_routes[1] eq 'refill'}active{/if}">{Lang::T('Refill Customer')}</a></li>
                        <li><a href="{Text::url('plan/voucher')}" class="rl-sub-link {if $_routes[1] eq 'voucher'}active{/if}">{Lang::T('Vouchers')}</a></li>
                    {/if}
                    {if $_c['enable_coupons'] == 'yes'}
                        <li><a href="{Text::url('coupons')}" class="rl-sub-link {if $_routes[0] eq 'coupons'}active{/if}">{Lang::T('Coupons')}</a></li>
                    {/if}
                    <li><a href="{Text::url('plan/recharge')}" class="rl-sub-link {if $_routes[1] eq 'recharge'}active{/if}">{Lang::T('Recharge Customer')}</a></li>
                    {if $_c['enable_balance'] == 'yes'}
                        <li><a href="{Text::url('plan/deposit')}" class="rl-sub-link {if $_routes[1] eq 'deposit'}active{/if}">{Lang::T('Refill Balance')}</a></li>
                    {/if}
                    {$_MENU_SERVICES}
                </ul>
            </li>
            {/if}
            {$_MENU_AFTER_SERVICES}

            <!-- Internet Plan -->
            {if in_array($_admin['user_type'],['SuperAdmin','Admin'])}
            <li class="rl-nav-item {if $_system_menu eq 'services'}active rl-open{/if}">
                <a href="javascript:void(0);" class="rl-nav-link">
                    <i class="ion ion-cube"></i>
                    <span>{Lang::T('Internet Plan')}</span>
                    <i class="fa fa-angle-right rl-arrow"></i>
                </a>
                <ul class="rl-submenu">
                    <li><a href="{Text::url('services/hotspot')}" class="rl-sub-link {if $_routes[1] eq 'hotspot'}active{/if}">Hotspot</a></li>
                    <li><a href="{Text::url('services/pppoe')}"   class="rl-sub-link {if $_routes[1] eq 'pppoe'}active{/if}">PPPOE</a></li>
                    <li><a href="{Text::url('services/vpn')}"     class="rl-sub-link {if $_routes[1] eq 'vpn'}active{/if}">VPN</a></li>
                    <li><a href="{Text::url('bandwidth/list')}"   class="rl-sub-link {if $_routes[1] eq 'list'}active{/if}">Bandwidth</a></li>
                    {if $_c['enable_balance'] == 'yes'}
                        <li><a href="{Text::url('services/balance')}" class="rl-sub-link {if $_routes[1] eq 'balance'}active{/if}">{Lang::T('Customer Balance')}</a></li>
                    {/if}
                    {$_MENU_PLANS}
                </ul>
            </li>
            {/if}
            {$_MENU_AFTER_PLANS}

            <!-- Maps -->
            <li class="rl-nav-item {if in_array($_routes[0], ['maps'])}active rl-open{/if}">
                <a href="javascript:void(0);" class="rl-nav-link">
                    <i class="fa fa-map-marker"></i>
                    <span>{Lang::T('Maps')}</span>
                    <i class="fa fa-angle-right rl-arrow"></i>
                </a>
                <ul class="rl-submenu">
                    <li><a href="{Text::url('maps/customer')}" class="rl-sub-link {if $_routes[1] eq 'customer'}active{/if}">{Lang::T('Customer')}</a></li>
                    <li><a href="{Text::url('maps/routers')}"  class="rl-sub-link {if $_routes[1] eq 'routers'}active{/if}">{Lang::T('Routers')}</a></li>
                    <li><a href="{Text::url('maps/odp')}"      class="rl-sub-link {if $_routes[1] eq 'odp'}active{/if}">{Lang::T('ODPs')}</a></li>
                    {$_MENU_MAPS}
                </ul>
            </li>

            <!-- Reports -->
            {if in_array($_admin['user_type'],['SuperAdmin','Admin','Report'])}
            <li class="rl-nav-item {if $_system_menu eq 'reports'}active rl-open{/if}">
                <a href="javascript:void(0);" class="rl-nav-link">
                    <i class="ion ion-clipboard"></i>
                    <span>{Lang::T('Reports')}</span>
                    <i class="fa fa-angle-right rl-arrow"></i>
                </a>
                <ul class="rl-submenu">
                    <li><a href="{Text::url('reports')}"              class="rl-sub-link {if $_routes[1] eq 'reports'}active{/if}">{Lang::T('Daily Reports')}</a></li>
                    <li><a href="{Text::url('reports/activation')}"   class="rl-sub-link {if $_routes[1] eq 'activation'}active{/if}">{Lang::T('Activation History')}</a></li>
                    {$_MENU_REPORTS}
                </ul>
            </li>
            {/if}
            {$_MENU_AFTER_REPORTS}

            <!-- Send Message -->
            <li class="rl-nav-item {if $_system_menu eq 'message'}active rl-open{/if}">
                <a href="javascript:void(0);" class="rl-nav-link">
                    <i class="ion ion-android-chat"></i>
                    <span>{Lang::T('Send Message')}</span>
                    <i class="fa fa-angle-right rl-arrow"></i>
                </a>
                <ul class="rl-submenu">
                    <li><a href="{Text::url('message/send')}"      class="rl-sub-link {if $_routes[1] eq 'send'}active{/if}">{Lang::T('Single Customer')}</a></li>
                    <li><a href="{Text::url('message/send_bulk')}" class="rl-sub-link {if $_routes[1] eq 'send_bulk'}active{/if}">{Lang::T('Bulk Customers')}</a></li>
                    {$_MENU_MESSAGE}
                </ul>
            </li>
            {$_MENU_AFTER_MESSAGE}

            <!-- Network -->
            {if in_array($_admin['user_type'],['SuperAdmin','Admin'])}
            <li class="rl-nav-item {if $_system_menu eq 'network'}active rl-open{/if}">
                <a href="javascript:void(0);" class="rl-nav-link">
                    <i class="ion ion-network"></i>
                    <span>{Lang::T('Network')}</span>
                    <i class="fa fa-angle-right rl-arrow"></i>
                </a>
                <ul class="rl-submenu">
                    <li><a href="{Text::url('routers')}"    class="rl-sub-link {if $_routes[0] eq 'routers' and $_routes[1] eq ''}active{/if}">Routers</a></li>
                    <li><a href="{Text::url('pool/list')}"  class="rl-sub-link {if $_routes[0] eq 'pool' and $_routes[1] eq 'list'}active{/if}">IP Pool</a></li>
                    <li><a href="{Text::url('pool/port')}"  class="rl-sub-link {if $_routes[0] eq 'pool' and $_routes[1] eq 'port'}active{/if}">Port Pool</a></li>
                    <li><a href="{Text::url('odp')}"        class="rl-sub-link {if $_routes[0] eq 'odp' and $_routes[1] eq ''}active{/if}">ODP List</a></li>
                    {$_MENU_NETWORK}
                </ul>
            </li>
            {/if}
            {$_MENU_AFTER_NETWORKS}

            <!-- Radius -->
            {if in_array($_admin['user_type'],['SuperAdmin','Admin']) && $_c['radius_enable']}
            <li class="rl-nav-item {if $_system_menu eq 'radius'}active rl-open{/if}">
                <a href="javascript:void(0);" class="rl-nav-link">
                    <i class="fa fa-database"></i>
                    <span>{Lang::T('Radius')}</span>
                    <i class="fa fa-angle-right rl-arrow"></i>
                </a>
                <ul class="rl-submenu">
                    <li><a href="{Text::url('radius/nas-list')}" class="rl-sub-link {if $_routes[0] eq 'radius' and $_routes[1] eq 'nas-list'}active{/if}">{Lang::T('Radius NAS')}</a></li>
                    {$_MENU_RADIUS}
                </ul>
            </li>
            {/if}
            {$_MENU_AFTER_RADIUS}

            <!-- Static Pages -->
            {if in_array($_admin['user_type'],['SuperAdmin','Admin'])}
            <li class="rl-nav-item {if $_system_menu eq 'pages'}active rl-open{/if}">
                <a href="javascript:void(0);" class="rl-nav-link">
                    <i class="ion ion-document"></i>
                    <span>{Lang::T("Static Pages")}</span>
                    <i class="fa fa-angle-right rl-arrow"></i>
                </a>
                <ul class="rl-submenu">
                    <li><a href="{Text::url('pages/Order_Voucher')}"        class="rl-sub-link {if $_routes[1] eq 'Order_Voucher'}active{/if}">{Lang::T('Order Voucher')}</a></li>
                    <li><a href="{Text::url('pages/Voucher')}"              class="rl-sub-link {if $_routes[1] eq 'Voucher'}active{/if}">{Lang::T('Theme Voucher')}</a></li>
                    <li><a href="{Text::url('pages/Announcement')}"         class="rl-sub-link {if $_routes[1] eq 'Announcement'}active{/if}">{Lang::T('Announcement')}</a></li>
                    <li><a href="{Text::url('pages/Announcement_Customer')}" class="rl-sub-link {if $_routes[1] eq 'Announcement_Customer'}active{/if}">{Lang::T('Customer Announcement')}</a></li>
                    <li><a href="{Text::url('pages/Registration_Info')}"    class="rl-sub-link {if $_routes[1] eq 'Registration_Info'}active{/if}">{Lang::T('Registration Info')}</a></li>
                    <li><a href="{Text::url('pages/Payment_Info')}"         class="rl-sub-link {if $_routes[1] eq 'Payment_Info'}active{/if}">{Lang::T('Payment Info')}</a></li>
                    <li><a href="{Text::url('pages/Privacy_Policy')}"       class="rl-sub-link {if $_routes[1] eq 'Privacy_Policy'}active{/if}">{Lang::T('Privacy Policy')}</a></li>
                    <li><a href="{Text::url('pages/Terms_and_Conditions')}" class="rl-sub-link {if $_routes[1] eq 'Terms_and_Conditions'}active{/if}">{Lang::T('Terms and Conditions')}</a></li>
                    {$_MENU_PAGES}
                </ul>
            </li>
            {/if}
            {$_MENU_AFTER_PAGES}

            <!-- Settings -->
            <li class="rl-nav-item {if $_system_menu eq 'settings' || $_system_menu eq 'paymentgateway'}active rl-open{/if}">
                <a href="javascript:void(0);" class="rl-nav-link">
                    <i class="ion ion-gear-a"></i>
                    <span>{Lang::T('Settings')}</span>
                    <i class="fa fa-angle-right rl-arrow"></i>
                </a>
                <ul class="rl-submenu">
                    {if in_array($_admin['user_type'],['SuperAdmin','Admin'])}
                        <li><a href="{Text::url('settings/app')}"            class="rl-sub-link {if $_routes[1] eq 'app'}active{/if}">{Lang::T('General Settings')}</a></li>
                        <li><a href="{Text::url('settings/localisation')}"   class="rl-sub-link {if $_routes[1] eq 'localisation'}active{/if}">{Lang::T('Localisation')}</a></li>
                        <li><a href="{Text::url('customfield')}"             class="rl-sub-link {if $_routes[0] eq 'customfield'}active{/if}">{Lang::T('Custom Fields')}</a></li>
                        <li><a href="{Text::url('settings/miscellaneous')}"  class="rl-sub-link {if $_routes[1] eq 'miscellaneous'}active{/if}">{Lang::T('Miscellaneous')}</a></li>
                        <li><a href="{Text::url('settings/maintenance')}"    class="rl-sub-link {if $_routes[1] eq 'maintenance'}active{/if}">{Lang::T('Maintenance Mode')}</a></li>
                        <li><a href="{Text::url('widgets')}"                 class="rl-sub-link {if $_routes[0] eq 'widgets'}active{/if}">{Lang::T('Widgets')}</a></li>
                        <li><a href="{Text::url('settings/notifications')}"  class="rl-sub-link {if $_routes[1] eq 'notifications'}active{/if}">{Lang::T('User Notification')}</a></li>
                        <li><a href="{Text::url('settings/devices')}"        class="rl-sub-link {if $_routes[1] eq 'devices'}active{/if}">{Lang::T('Devices')}</a></li>
                    {/if}
                    {if in_array($_admin['user_type'],['SuperAdmin','Admin','Agent'])}
                        <li><a href="{Text::url('settings/users')}"          class="rl-sub-link {if $_routes[1] eq 'users'}active{/if}">{Lang::T('Administrator Users')}</a></li>
                    {/if}
                    {if in_array($_admin['user_type'],['SuperAdmin','Admin'])}
                        <li><a href="{Text::url('settings/dbstatus')}"       class="rl-sub-link {if $_routes[1] eq 'dbstatus'}active{/if}">{Lang::T('Backup/Restore')}</a></li>
                        <li><a href="{Text::url('paymentgateway')}"          class="rl-sub-link {if $_system_menu eq 'paymentgateway'}active{/if}">{Lang::T('Payment Gateway')}</a></li>
                        {$_MENU_SETTINGS}
                        <li><a href="{Text::url('pluginmanager')}"           class="rl-sub-link {if $_routes[0] eq 'pluginmanager'}active{/if}">{Lang::T('Plugin Manager')}</a></li>
                    {/if}
                </ul>
            </li>
            {$_MENU_AFTER_SETTINGS}

            <!-- Logs -->
            {if in_array($_admin['user_type'],['SuperAdmin','Admin'])}
            <li class="rl-nav-item {if $_system_menu eq 'logs'}active rl-open{/if}">
                <a href="javascript:void(0);" class="rl-nav-link">
                    <i class="ion ion-clock"></i>
                    <span>{Lang::T('Logs')}</span>
                    <i class="fa fa-angle-right rl-arrow"></i>
                </a>
                <ul class="rl-submenu">
                    <li><a href="{Text::url('logs/phpnuxbill')}" class="rl-sub-link {if $_routes[1] eq 'list'}active{/if}">PhpNuxBill</a></li>
                    {if $_c['radius_enable']}
                        <li><a href="{Text::url('logs/radius')}" class="rl-sub-link {if $_routes[1] eq 'radius'}active{/if}">Radius</a></li>
                    {/if}
                    <li><a href="{Text::url('logs/message')}"    class="rl-sub-link {if $_routes[1] eq 'message'}active{/if}">Message</a></li>
                    {$_MENU_LOGS}
                </ul>
            </li>
            {/if}
            {$_MENU_AFTER_LOGS}

            <!-- Documentation & Community -->
            {if in_array($_admin['user_type'],['SuperAdmin','Admin'])}
            <li class="rl-nav-item {if $_routes[1] eq 'docs'}active{/if}">
                <a href="{if $_c['docs_clicked'] != 'yes'}{Text::url('settings/docs')}{else}{$app_url}/docs{/if}" class="rl-nav-link">
                    <i class="ion ion-ios-bookmarks"></i>
                    <span>{Lang::T('Documentation')}</span>
                </a>
            </li>
            <li class="rl-nav-item {if $_system_menu eq 'community'}active{/if}">
                <a href="{Text::url('community')}" class="rl-nav-link">
                    <i class="ion ion-chatboxes"></i>
                    <span>Community</span>
                </a>
            </li>
            {/if}
            {$_MENU_AFTER_COMMUNITY}
        </ul>
    </aside>

    <!-- Overlay mobile -->
    <div class="rl-overlay" id="rlOverlay"></div>

    <!-- ============================= MAIN CONTENT ============================= -->
    <div class="rl-content" id="rlContent">

        <!-- Search overlay -->
        <div class="rl-search-overlay" id="rlSearchOverlay">
            <div class="rl-search-box">
                <input type="text" id="rlSearchTerm" placeholder="{Lang::T('Search Users')}" autocomplete="off">
                <div class="rl-search-results" id="rlSearchResults"></div>
                <div class="rl-search-foot">
                    <button type="button" id="rlSearchClose">{Lang::T('Cancel')} (ESC)</button>
                </div>
            </div>
        </div>

        <!-- Maintenance bar -->
        {if $_c['maintenance_mode'] == 1}
        <div class="rl-maintenance">
            <span>
                <i class="fa fa-exclamation-triangle"></i>
                {Lang::T('The website is currently in maintenance mode, this means that some or all functionality may be unavailable to regular users during this time.')}
            </span>
            <a href="{Text::url('settings/maintenance')}">{Lang::T('Turn Off')}</a>
        </div>
        {/if}

        <!-- Content header -->
        <div class="rl-content-header">
            <h1>
                <i class="fa fa-tachometer"></i> {$_title}
            </h1>
        </div>

        <!-- Content body -->
        <div class="rl-content-body">

        {if isset($notify)}
            <script>
                Swal.fire({
                    icon: '{if $notify_t == "s"}success{else}error{/if}',
                    title: '{$notify}',
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 5000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer);
                        toast.addEventListener('mouseleave', Swal.resumeTimer);
                    }
                });
            </script>
        {/if}