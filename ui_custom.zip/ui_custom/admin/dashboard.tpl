{include file="sections/header.tpl"}

{function showWidget pos=0}
    {foreach $widgets as $w}
        {if $w['position'] == $pos}
            {$w['content']}
        {/if}
    {/foreach}
{/function}

{assign dtipe value="dashboard_`$tipeUser`"}
{assign rows explode(".", $_c[$dtipe])}
{assign pos 1}

<style>
/* ============================================================
   Modern Dashboard Skin (RLradius-inspired) — PHPNuxBill
   Kompatibel dengan AdminLTE 2/3 + Bootstrap 3
   ============================================================ */
.rl-dash {
    --rl-border: rgba(15, 23, 42, .08);
    --rl-text: #0f172a;
    --rl-muted: #64748b;
    --rl-primary: #0d6efd;
    --rl-success: #198754;
    --rl-warning: #d97706;
    --rl-danger: #dc3545;
    --rl-info: #0aa2c0;
    --rl-card: #ffffff;
    --rl-hover: rgba(13, 110, 253, .04);
    padding: 0 4px;
}

/* ---------- Card dasar ---------- */
.rl-dash .rl-card {
    background: var(--rl-card);
    border: 1px solid var(--rl-border);
    border-radius: 10px;
    overflow: hidden;
    margin-bottom: 16px;
}
.rl-dash .rl-card-header {
    padding: 10px 16px;
    border-bottom: 1px solid var(--rl-border);
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 6px;
}
.rl-dash .rl-card-title {
    font-size: 12px;
    font-weight: 700;
    letter-spacing: .04em;
    text-transform: uppercase;
    color: var(--rl-muted);
    margin: 0;
}
.rl-dash .rl-card-title i { margin-right: 4px; }
.rl-dash .rl-badge-live {
    font-size: 10px;
    font-weight: 700;
    letter-spacing: .06em;
    text-transform: uppercase;
    padding: 2px 8px;
    border-radius: 999px;
    background: rgba(25, 135, 84, .1);
    color: var(--rl-success);
}
.rl-dash .rl-badge-live i { font-size: 5px; vertical-align: middle; margin-right: 3px; }

/* ---------- Bento Grid ---------- */
.rl-bento {
    display: grid;
    grid-template-columns: 1fr;
    gap: 1px;
    background: var(--rl-border);
}
@media (min-width: 576px) { .rl-bento { grid-template-columns: repeat(2, 1fr); } }
@media (min-width: 992px) { .rl-bento { grid-template-columns: repeat(3, 1fr); } }

.rl-bento-cell {
    background: #fff;
    padding: 14px 13px 13px 18px;
    min-height: 108px;
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    grid-template-rows: auto auto auto;
    column-gap: 10px;
    row-gap: 3px;
    align-items: center;
    cursor: pointer;
    transition: background-color .2s ease;
    position: relative;
}
.rl-bento-cell:hover { background: var(--rl-hover); }
.rl-bento-cell::before {
    content: '';
    position: absolute;
    left: 0; top: 12px; bottom: 12px;
    width: 3px;
    border-radius: 0 3px 3px 0;
    background: var(--rl-primary);
    opacity: .7;
}
.rl-bento-cell.rl-success::before { background: var(--rl-success); }
.rl-bento-cell.rl-warning::before { background: var(--rl-warning); }
.rl-bento-cell.rl-muted::before   { background: #94a3b8; }
.rl-bento-cell.rl-info::before    { background: var(--rl-info); }

.rl-bento-tag {
    grid-column: 1; grid-row: 1;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: .05em;
    text-transform: uppercase;
    color: var(--rl-muted);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    align-self: center;
}
.rl-bento-value {
    grid-column: 1; grid-row: 2;
    font-size: 22px;
    font-weight: 800;
    line-height: 1.1;
    color: var(--rl-text);
    font-variant-numeric: tabular-nums;
    word-break: break-word;
    align-self: start;
}
.rl-bento-cell.rl-info    .rl-bento-value { color: var(--rl-primary); }
.rl-bento-cell.rl-success .rl-bento-value { color: var(--rl-success); }
.rl-bento-cell.rl-warning .rl-bento-value { color: var(--rl-warning); }
.rl-bento-cell.rl-muted   .rl-bento-value { color: #6c757d; }

.rl-bento-label {
    grid-column: 1; grid-row: 3;
    font-size: 10.5px;
    color: var(--rl-muted);
    line-height: 1.25;
    align-self: start;
}
.rl-bento-icon {
    grid-column: 2;
    grid-row: 1 / -1;
    width: 54px; height: 54px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    line-height: 1;
    align-self: center;
    justify-self: end;
}
.rl-bento-cell.rl-info    .rl-bento-icon { background: rgba(13,110,253,.14); color: var(--rl-primary); }
.rl-bento-cell.rl-success .rl-bento-icon { background: rgba(25,135,84,.14);  color: var(--rl-success); }
.rl-bento-cell.rl-warning .rl-bento-icon { background: rgba(245,158,11,.16); color: var(--rl-warning); }
.rl-bento-cell.rl-muted   .rl-bento-icon { background: rgba(108,117,125,.16); color: #6c757d; }

/* ---------- Log Feed ---------- */
.rl-log-list { list-style: none; padding: 0; margin: 0; }
.rl-log-item { border-bottom: 1px solid var(--rl-border); }
.rl-log-item:last-child { border-bottom: 0; }
.rl-log-link {
    display: flex;
    gap: 10px;
    padding: 10px 14px;
    color: inherit;
    text-decoration: none;
    transition: background-color .2s ease;
}
.rl-log-link:hover { background: var(--rl-hover); color: inherit; text-decoration: none; }
.rl-log-icon {
    width: 32px; height: 32px;
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-size: 11px;
    flex-shrink: 0;
}
.rl-log-body { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }
.rl-log-top {
    display: flex; align-items: flex-start; justify-content: space-between;
    gap: 8px;
}
.rl-log-name { font-size: 13px; font-weight: 700; color: var(--rl-text); line-height: 1.3; word-break: break-word; }
.rl-log-time { font-size: 10px; font-weight: 600; color: #94a3b8; white-space: nowrap; flex-shrink: 0; }
.rl-log-msg  { font-size: 12px; color: #475569; line-height: 1.45; word-break: break-word; }
.rl-log-empty { padding: 20px 14px; font-size: 12px; text-align: center; color: var(--rl-muted); }
.rl-log-more { font-size: 10.5px; font-weight: 700; letter-spacing: .04em; text-transform: uppercase; color: var(--rl-primary); text-decoration: none; }
.rl-log-more:hover { text-decoration: none; opacity: .85; color: var(--rl-primary); }

/* ---------- Info Card (lisensi / sistem) ---------- */
.rl-info-list { display: flex; flex-direction: column; gap: 10px; padding: 12px; }
.rl-info-item {
    border-radius: 12px;
    background: rgba(15,23,42,.03);
    border: 1px solid rgba(15,23,42,.06);
    padding: 12px 13px;
}
.rl-info-row { display: flex; align-items: flex-start; gap: 12px; }
.rl-info-icon {
    width: 36px; height: 36px;
    border-radius: 12px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    font-size: 14px;
}
.rl-info-icon.rl-success { background: rgba(25,135,84,.12); color: var(--rl-success); }
.rl-info-icon.rl-primary { background: rgba(13,110,253,.12); color: var(--rl-primary); }
.rl-info-icon.rl-info    { background: rgba(13,202,240,.12); color: var(--rl-info); }
.rl-info-icon.rl-warning { background: rgba(245,158,11,.16); color: var(--rl-warning); }
.rl-info-body { flex: 1; min-width: 0; }
.rl-info-head {
    display: flex; align-items: flex-start; justify-content: space-between; gap: 8px;
    margin-bottom: 6px;
}
.rl-info-label { font-size: 12.5px; line-height: 1.4; font-weight: 600; color: #334155; }
.rl-info-persen { font-size: 13px; font-weight: 800; color: var(--rl-text); flex-shrink: 0; }
.rl-info-bar {
    height: 8px;
    background: rgba(15,23,42,.08);
    border-radius: 999px;
    overflow: hidden;
}
.rl-info-bar .progress-bar { border-radius: 999px; }
.rl-meta {
    border: 1px solid rgba(13,110,253,.15);
    border-radius: 12px;
    background: rgba(13,110,253,.05);
    padding: 14px 15px;
    font-size: 12px;
    line-height: 1.7;
    color: #475569;
}
.rl-meta-title {
    font-size: 15px; font-weight: 800; color: var(--rl-text); margin: 0 0 8px;
}
.rl-meta-hl { color: var(--rl-primary); font-weight: 800; }

/* ---------- Finance mini card ---------- */
.rl-fin-value {
    font-size: 22px; font-weight: 800; margin: 0 0 4px;
    font-variant-numeric: tabular-nums;
}
.rl-fin-label { font-size: 12px; color: var(--rl-muted); margin: 0; }
.rl-fin-item { padding: 14px 16px; border-bottom: 1px solid var(--rl-border); cursor: pointer; }
.rl-fin-item:last-child { border-bottom: 0; }
.rl-fin-item:hover { background: var(--rl-hover); }
.rl-fin-item.text-success .rl-fin-value { color: var(--rl-success); }
.rl-fin-item.text-danger  .rl-fin-value { color: var(--rl-danger); }
.rl-fin-item.text-primary .rl-fin-value { color: var(--rl-primary); }

/* ---------- Chart toolbar ---------- */
.rl-chart-toolbar {
    display: flex; gap: 8px; padding: 10px 14px 0; justify-content: flex-end; flex-wrap: wrap;
}
.rl-chart-toolbar select,
.rl-chart-toolbar input {
    height: 30px; font-size: 12px; padding: 2px 8px;
    border-radius: 6px; border: 1px solid var(--rl-border);
}

@media (max-width: 575px) {
    .rl-log-top { flex-direction: column; gap: 2px; }
    .rl-log-time { white-space: normal; }
    .rl-fin-value { font-size: 18px; }
}
</style>

<div class="rl-dash content-wrapper" style="padding: 12px 8px;">

    <!-- ============================= -->
    <!-- BENTO GRID RINGKASAN HARI INI -->
    <!-- ============================= -->
    <div class="rl-card">
        <div class="rl-card-header">
            <h6 class="rl-card-title"><i class="fa fa-th-large"></i> {Lang::T('Ringkasan Hari Ini')}</h6>
            <span class="rl-badge-live"><i class="fa fa-circle"></i> Live</span>
        </div>
        <div class="rl-bento">
            <div class="rl-bento-cell rl-info" onclick="location.href='{Text::url('reports')}'">
                <span class="rl-bento-tag">{Lang::T('Pemasukan Hari Ini')}</span>
                <span class="rl-bento-icon"><i class="fa fa-money"></i></span>
                <div class="rl-bento-value" id="rl_income_today">0</div>
                <div class="rl-bento-label">{Lang::T('Keuangan')}</div>
            </div>
            <div class="rl-bento-cell rl-success" onclick="location.href='{Text::url('customers')}'">
                <span class="rl-bento-tag">{Lang::T('Pelanggan Aktif')}</span>
                <span class="rl-bento-icon"><i class="fa fa-users"></i></span>
                <div class="rl-bento-value" id="rl_customers_active">0</div>
                <div class="rl-bento-label">{Lang::T('Total User')}</div>
            </div>
            <div class="rl-bento-cell rl-info" onclick="location.href='{Text::url('plan/list')}'">
                <span class="rl-bento-tag">{Lang::T('User Online')}</span>
                <span class="rl-bento-icon"><i class="fa fa-wifi"></i></span>
                <div class="rl-bento-value" id="rl_online">0</div>
                <div class="rl-bento-label">{Lang::T('PPPoE / Hotspot')}</div>
            </div>
            <div class="rl-bento-cell rl-muted" onclick="location.href='{Text::url('plan/list')}'">
                <span class="rl-bento-tag">{Lang::T('Pelanggan Expired')}</span>
                <span class="rl-bento-icon"><i class="fa fa-calendar-times-o"></i></span>
                <div class="rl-bento-value" id="rl_expired">0</div>
                <div class="rl-bento-label">{Lang::T('Perlu Perpanjangan')}</div>
            </div>
            <div class="rl-bento-cell rl-warning" onclick="location.href='{Text::url('plan/voucher')}'">
                <span class="rl-bento-tag">{Lang::T('Voucher Aktif')}</span>
                <span class="rl-bento-icon"><i class="fa fa-ticket"></i></span>
                <div class="rl-bento-value" id="rl_voucher">0</div>
                <div class="rl-bento-label">{Lang::T('Siap Jual')}</div>
            </div>
            <div class="rl-bento-cell rl-success" onclick="location.href='{Text::url('plan/deposit')}'">
                <span class="rl-bento-tag">{Lang::T('Saldo Pelanggan')}</span>
                <span class="rl-bento-icon"><i class="fa fa-credit-card"></i></span>
                <div class="rl-bento-value" id="rl_balance">0</div>
                <div class="rl-bento-label">{Lang::T('Total Deposit')}</div>
            </div>
        </div>
    </div>

    <!-- ============================= -->
    <!-- LOG FEED + INFO SISTEM -->
    <!-- ============================= -->
    <div class="row">
        <div class="col-md-8">
            <div class="rl-card">
                <div class="rl-card-header">
                    <h6 class="rl-card-title"><i class="fa fa-list-alt"></i> {Lang::T('Log Aplikasi')}</h6>
                    <a href="{Text::url('logs/phpnuxbill')}" class="rl-log-more">
                        {Lang::T('Lihat Semua')} <i class="fa fa-arrow-right"></i>
                    </a>
                </div>
                <ul class="rl-log-list" id="rl_log_feed">
                    <li class="rl-log-empty">{Lang::T('Memuat log...')}</li>
                </ul>
            </div>
        </div>

        <div class="col-md-4">
            <div class="rl-card">
                <div class="rl-card-header">
                    <h6 class="rl-card-title"><i class="fa fa-info-circle"></i> {Lang::T('Informasi Sistem')}</h6>
                </div>
                <div class="rl-info-list">
                    <div class="rl-info-item">
                        <div class="rl-info-row">
                            <span class="rl-info-icon rl-success"><i class="fa fa-users"></i></span>
                            <div class="rl-info-body">
                                <div class="rl-info-head">
                                    <span class="rl-info-label">{Lang::T('Pelanggan Aktif')}</span>
                                    <span class="rl-info-persen" id="rl_persen_customer">0%</span>
                                </div>
                                <div class="progress rl-info-bar">
                                    <div class="progress-bar bg-success" id="rl_bar_customer" style="width:0%"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rl-info-item">
                        <div class="rl-info-row">
                            <span class="rl-info-icon rl-primary"><i class="fa fa-ticket"></i></span>
                            <div class="rl-info-body">
                                <div class="rl-info-head">
                                    <span class="rl-info-label">{Lang::T('Voucher Terjual')}</span>
                                    <span class="rl-info-persen" id="rl_persen_voucher">0%</span>
                                </div>
                                <div class="progress rl-info-bar">
                                    <div class="progress-bar bg-primary" id="rl_bar_voucher" style="width:0%"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="rl-info-item">
                        <div class="rl-info-row">
                            <span class="rl-info-icon rl-info"><i class="fa fa-server"></i></span>
                            <div class="rl-info-body">
                                <div class="rl-info-head">
                                    <span class="rl-info-label">{Lang::T('Router Aktif')}</span>
                                    <span class="rl-info-persen" id="rl_persen_router">0%</span>
                                </div>
                                <div class="progress rl-info-bar">
                                    <div class="progress-bar bg-info" id="rl_bar_router" style="width:0%"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="rl-meta">
                        <h5 class="rl-meta-title">{$_c['CompanyName']}</h5>
                        {Lang::T('Versi Aplikasi')} : <span class="rl-meta-hl">{$_c['version']|default:'-'}</span><br>
                        {Lang::T('Zona Waktu')}    : <span class="rl-meta-hl">{$_c['timezone']|default:'Asia/Jakarta'}</span><br>
                        {Lang::T('Tipe User')}     : <span class="rl-meta-hl">{Lang::T($_admin['user_type'])}</span><br>
                        {Lang::T('Terakhir Login')}: <span class="rl-meta-hl">{$_admin['last_login']|default:'-'}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================= -->
    <!-- FINANCE + CHART -->
    <!-- ============================= -->
    <div class="row">
        <div class="col-md-5">
            <div class="rl-card">
                <div class="rl-card-header">
                    <h6 class="rl-card-title"><i class="fa fa-calendar"></i> {Lang::T('Transaksi Bulan Ini')}</h6>
                </div>
                <div class="rl-fin-item text-success" onclick="location.href='{Text::url('reports')}'">
                    <h3 class="rl-fin-value" id="rl_income_month">Rp 0</h3>
                    <p class="rl-fin-label">{Lang::T('Total pemasukan bulan ini')}</p>
                </div>
                <div class="rl-fin-item text-danger" onclick="location.href='{Text::url('reports')}'">
                    <h3 class="rl-fin-value" id="rl_expense_month">Rp 0</h3>
                    <p class="rl-fin-label">{Lang::T('Total pengeluaran bulan ini')}</p>
                </div>
                <div class="rl-fin-item text-primary" onclick="location.href='{Text::url('reports')}'">
                    <h3 class="rl-fin-value" id="rl_profit_month">Rp 0</h3>
                    <p class="rl-fin-label">{Lang::T('Total profit bulan ini')}</p>
                </div>
            </div>
        </div>

        <div class="col-md-7">
            <div class="rl-card">
                <div class="rl-card-header">
                    <h6 class="rl-card-title"><i class="fa fa-area-chart"></i> {Lang::T('Grafik Pemasukan & Pengeluaran')}</h6>
                </div>
                <div class="rl-chart-toolbar">
                    <select id="rl_chart_month" class="form-control input-sm">
                        <option value="01">JANUARI</option>
                        <option value="02">FEBRUARI</option>
                        <option value="03">MARET</option>
                        <option value="04">APRIL</option>
                        <option value="05">MEI</option>
                        <option value="06">JUNI</option>
                        <option value="07">JULI</option>
                        <option value="08">AGUSTUS</option>
                        <option value="09">SEPTEMBER</option>
                        <option value="10">OKTOBER</option>
                        <option value="11">NOVEMBER</option>
                        <option value="12">DESEMBER</option>
                    </select>
                    <input type="text" id="rl_chart_year" class="form-control input-sm" style="width:80px;" value="{$smarty.now|date_format:'%Y'}">
                </div>
                <div class="card-body" style="padding:8px 12px 12px;">
                    <canvas id="rlChartFinance" height="180"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================= -->
    <!-- WIDGET LAMA TETAP DIPERTAHANKAN -->
    <!-- ============================= -->
    {foreach $rows as $cols}
        {if $cols == 12}
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    {showWidget widgets=$widgets pos=$pos}
                </div>
            </div>
            {assign pos value=$pos+1}
        {else}
            {assign colss explode(",", $cols)}
            <div class="row">
                {foreach $colss as $c}
                    <div class="col-md-{$c} col-sm-6 col-xs-12">
                        {showWidget widgets=$widgets pos=$pos}
                    </div>
                    {assign pos value=$pos+1}
                {/foreach}
            </div>
        {/if}
    {/foreach}

</div>

<!-- ============================================================ -->
<!-- SCRIPT: helper format, polling, chart                         -->
<!-- ============================================================ -->
<script>
(function () {
    'use strict';

    // ---------- Helpers ----------
    const formatRupiah = (val) => {
        const n = Number(val || 0);
        return 'Rp' + n.toLocaleString('id-ID');
    };
    const formatNumber = (val) => Number(val || 0).toLocaleString('id-ID');
    const escapeHtml = (s) => String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

    // ---------- Server Clock (live) ----------
    const clockEl = document.getElementById('servertime');
    if (clockEl) {
        const baseParts = clockEl.textContent.trim().split(':').map(Number);
        const baseTime = new Date();
        baseTime.setHours(baseParts[0] || 0, baseParts[1] || 0, baseParts[2] || 0);
        const diff = Date.now() - baseTime.getTime();
        const pad = (n) => String(n).padStart(2, '0');
        const tickClock = () => {
            const now = new Date(Date.now() - diff);
            clockEl.textContent = pad(now.getHours()) + ':' + pad(now.getMinutes()) + ':' + pad(now.getSeconds());
        };
        tickClock();
        setInterval(tickClock, 1000);
    }

    // ---------- Update UI dari payload ----------
    const applyDashboardData = (data) => {
        if (!data) return;

        document.getElementById('rl_income_today').textContent       = formatRupiah(data.income_today);
        document.getElementById('rl_customers_active').textContent   = formatNumber(data.customers_active);
        document.getElementById('rl_online').textContent             = formatNumber(data.online);
        document.getElementById('rl_expired').textContent            = formatNumber(data.expired);
        document.getElementById('rl_voucher').textContent            = formatNumber(data.voucher_active);
        document.getElementById('rl_balance').textContent            = formatRupiah(data.total_balance);

        document.getElementById('rl_income_month').textContent  = formatRupiah(data.income_month);
        document.getElementById('rl_expense_month').textContent = formatRupiah(data.expense_month);
        document.getElementById('rl_profit_month').textContent  = formatRupiah((data.income_month || 0) - (data.expense_month || 0));

        // Info bar persen
        const setBar = (barId, persenId, percent) => {
            const p = Math.min(100, Math.max(0, Math.round(Number(percent) || 0)));
            const bar = document.getElementById(barId);
            const txt = document.getElementById(persenId);
            if (bar) bar.style.width = p + '%';
            if (txt) txt.textContent = p + '%';
        };
        setBar('rl_bar_customer', 'rl_persen_customer', data.percent_customer);
        setBar('rl_bar_voucher',  'rl_persen_voucher',  data.percent_voucher);
        setBar('rl_bar_router',   'rl_persen_router',   data.percent_router);
    };

    // ---------- Render log feed ----------
    const renderLogFeed = (items) => {
        const list = document.getElementById('rl_log_feed');
        if (!list) return;
        if (!items || !items.length) {
            list.innerHTML = '<li class="rl-log-empty">Tidak ada log terbaru</li>';
            return;
        }
        list.innerHTML = items.map((row) => {
            const color = row.status === 'success' ? 'bg-success'
                       : row.status === 'warning' ? 'bg-warning'
                       : 'bg-info';
            return ''
              + '<li class="rl-log-item">'
              +   '<a href="{Text::url('logs/phpnuxbill')}" class="rl-log-link">'
              +     '<span class="rl-log-icon ' + color + '"><i class="fa fa-user"></i></span>'
              +     '<span class="rl-log-body">'
              +       '<span class="rl-log-top">'
              +         '<span class="rl-log-name">' + escapeHtml(row.name) + '</span>'
              +         '<span class="rl-log-time">' + escapeHtml(row.ip) + ' - ' + escapeHtml(row.time) + '</span>'
              +       '</span>'
              +       '<span class="rl-log-msg">' + escapeHtml(row.message) + '</span>'
              +     '</span>'
              +   '</a>'
              + '</li>';
        }).join('');
    };

    // ---------- Idle-aware poll ----------
    const startIdleAwarePoll = ({ intervalMs, idleMs, tick, immediate }) => {
        let timer = null, lastActivity = Date.now();
        const bump = () => { lastActivity = Date.now(); };
        ['mousemove','keydown','scroll','click','touchstart'].forEach((ev) =>
            document.addEventListener(ev, bump, { passive: true }));

        const isActive = () => !document.hidden && (Date.now() - lastActivity) < idleMs;
        const run = (force) => { if (force || isActive()) tick(); };
        const start = () => { if (timer === null) timer = setInterval(() => run(false), intervalMs); };
        const stop  = () => { if (timer !== null) { clearInterval(timer); timer = null; } };

        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) { lastActivity = Date.now(); run(true); }
        });

        if (immediate) run(true);
        start();
        return { start, stop, tick: () => run(true) };
    };

    // ---------- Refresh data dashboard ----------
    const refreshDashboard = () => {
        $.ajax({
            url: '{Text::url('dashboard/data')}',
            dataType: 'json',
            global: false,
            success: (res) => {
                applyDashboardData(res);
                if (res.logs) renderLogFeed(res.logs);
            }
        });
    };

    // ---------- Chart.js ----------
    const initChart = () => {
        const ctx = document.getElementById('rlChartFinance');
        if (!ctx || typeof Chart === 'undefined') return null;

        const chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [
                    {
                        label: 'Pemasukan',
                        data: [],
                        borderColor: '#0d6efd',
                        backgroundColor: 'rgba(13,110,253,.15)',
                        fill: true,
                        tension: 0.35,
                        borderWidth: 2,
                        pointRadius: 0
                    },
                    {
                        label: 'Pengeluaran',
                        data: [],
                        borderColor: '#dc3545',
                        backgroundColor: 'rgba(220,53,69,.15)',
                        fill: true,
                        tension: 0.35,
                        borderWidth: 2,
                        pointRadius: 0
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'top', align: 'end' },
                    tooltip: {
                        callbacks: {
                            label: (c) => c.dataset.label + ': ' + formatRupiah(c.parsed.y)
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: (v) => {
                                if (v >= 1e9) return (v/1e9).toFixed(1) + ' M';
                                if (v >= 1e6) return (v/1e6).toFixed(1) + ' jt';
                                if (v >= 1e3) return (v/1e3).toFixed(0) + ' rb';
                                return v;
                            }
                        },
                        grid: { color: 'rgba(15,23,42,.06)' }
                    },
                    x: { grid: { display: false } }
                }
            }
        });

        const loadChart = () => {
            const month = document.getElementById('rl_chart_month').value;
            const year  = document.getElementById('rl_chart_year').value;
            $.ajax({
                url: '{Text::url('dashboard/chart')}',
                method: 'POST',
                dataType: 'json',
                global: false,
                data: { bulan: month, tahun: year },
                success: (res) => {
                    chart.data.labels = res.tanggal || [];
                    chart.data.datasets[0].data = res.total || [];
                    chart.data.datasets[1].data = res.pengeluaran || [];
                    chart.update();
                }
            });
        };

        // Set default bulan/tahun
        const d = new Date();
        document.getElementById('rl_chart_month').value = String(d.getMonth() + 1).padStart(2, '0');
        document.getElementById('rl_chart_year').value  = d.getFullYear();

        document.getElementById('rl_chart_month').addEventListener('change', loadChart);
        document.getElementById('rl_chart_year').addEventListener('change', loadChart);
        loadChart();
        return chart;
    };

    // ---------- Boot ----------
    $(function () {
        // Polling data (30s, idle 3 menit)
        startIdleAwarePoll({
            intervalMs: 30000,
            idleMs: 180000,
            immediate: true,
            tick: refreshDashboard
        });

        // Chart
        initChart();
    });

})();
</script>

{include file="sections/footer.tpl"}