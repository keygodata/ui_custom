        </div><!-- /.rl-content-body -->

        <footer class="rl-footer">
            <div>
                &copy; {$smarty.now|date_format:'%Y'} {$_c['CompanyName']} — {Lang::T('All rights reserved')}.
            </div>
            <div>
                <span id="version">{Lang::T('Version')}: —</span>
            </div>
        </footer>

    </div><!-- /.rl-content -->
</div><!-- /.rl-wrapper -->

<!-- ============================================================
     THEME JS — sidebar toggle, submenu, dropdown, clock, search
     ============================================================ -->
<script>
(function () {
    'use strict';

    // ---------- Sidebar toggle (desktop collapse / mobile off-canvas) ----------
    const body = document.body;
    const sidebarToggle = document.getElementById('rlSidebarToggle');
    const overlay = document.getElementById('rlOverlay');

    const isMobile = () => window.innerWidth < 992;

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function () {
            if (isMobile()) {
                body.classList.toggle('rl-mobile-open');
                overlay.classList.toggle('rl-show', body.classList.contains('rl-mobile-open'));
            } else {
                body.classList.toggle('rl-mini');
                try { localStorage.setItem('rl_mini', body.classList.contains('rl-mini') ? '1' : '0'); } catch (e) {}
                if (typeof setKolaps === 'function') { try { setKolaps(); } catch (e) {} }
            }
        });
    }
    if (overlay) {
        overlay.addEventListener('click', function () {
            body.classList.remove('rl-mobile-open');
            overlay.classList.remove('rl-show');
        });
    }

    // Restore mini state
    try {
        if (localStorage.getItem('rl_mini') === '1') body.classList.add('rl-mini');
        if (localStorage.getItem('rl_dark') === '1') body.classList.add('rl-dark');
    } catch (e) {}

    // ---------- Submenu toggle ----------
    document.querySelectorAll('#rlNav .rl-nav-item > .rl-nav-link').forEach(function (link) {
        const parent = link.parentElement;
        const submenu = parent.querySelector('.rl-submenu');
        if (!submenu) return;
        link.addEventListener('click', function (e) {
            if (body.classList.contains('rl-mini') && !isMobile()) return;
            e.preventDefault();
            const isOpen = parent.classList.contains('rl-open');
            // Close siblings (accordion)
            parent.parentElement.querySelectorAll('.rl-nav-item.rl-open').forEach(function (el) {
                if (el !== parent) el.classList.remove('rl-open');
            });
            parent.classList.toggle('rl-open', !isOpen);
        });
    });

    // ---------- User dropdown ----------
    const userBtn = document.getElementById('rlUserDropdownBtn');
    const userDrop = document.getElementById('rlUserDropdown');
    if (userBtn && userDrop) {
        userBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            userDrop.classList.toggle('rl-show');
        });
        document.addEventListener('click', function (e) {
            if (!userDrop.contains(e.target) && e.target !== userBtn) {
                userDrop.classList.remove('rl-show');
            }
        });
    }

    // ---------- Theme toggle ----------
    const themeBtn = document.getElementById('rlThemeBtn');
    if (themeBtn) {
        themeBtn.addEventListener('click', function () {
            body.classList.toggle('rl-dark');
            try { localStorage.setItem('rl_dark', body.classList.contains('rl-dark') ? '1' : '0'); } catch (e) {}
            themeBtn.querySelector('i').className = body.classList.contains('rl-dark') ? 'fa fa-sun-o' : 'fa fa-moon-o';
        });
        if (body.classList.contains('rl-dark')) {
            themeBtn.querySelector('i').className = 'fa fa-sun-o';
        }
    }

    // ---------- Search overlay ----------
    const searchBtn = document.getElementById('rlSearchBtn');
    const searchOverlay = document.getElementById('rlSearchOverlay');
    const searchTerm = document.getElementById('rlSearchTerm');
    const searchResults = document.getElementById('rlSearchResults');
    const searchClose = document.getElementById('rlSearchClose');

    const openSearch = () => {
        if (!searchOverlay) return;
        searchOverlay.classList.add('rl-open');
        setTimeout(() => searchTerm && searchTerm.focus(), 50);
    };
    const closeSearch = () => {
        if (!searchOverlay) return;
        searchOverlay.classList.remove('rl-open');
        if (searchTerm) searchTerm.value = '';
        if (searchResults) searchResults.innerHTML = '';
    };

    if (searchBtn) searchBtn.addEventListener('click', openSearch);
    if (searchClose) searchClose.addEventListener('click', closeSearch);
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') closeSearch();
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); openSearch(); }
    });
    if (searchOverlay) {
        searchOverlay.addEventListener('click', function (e) {
            if (e.target === searchOverlay) closeSearch();
        });
    }

    // ---------- Live search via PHPNuxBill endpoint ----------
    let searchTimer = null;
    if (searchTerm) {
        searchTerm.addEventListener('input', function () {
            const q = this.value.trim();
            clearTimeout(searchTimer);
            if (q.length < 2) { searchResults.innerHTML = ''; return; }
            searchTimer = setTimeout(function () {
                searchResults.innerHTML = '<div style="padding:16px;color:#64748b;font-size:12px;">Mencari...</div>';
                $.ajax({
                    url: appUrl + '/?_route=customers&search=' + encodeURIComponent(q),
                    dataType: 'html',
                    success: function (html) {
                        // Fallback: redirect search langsung
                        searchResults.innerHTML = ''
                          + '<a class="rl-result" href="' + appUrl + '/?_route=customers&search=' + encodeURIComponent(q) + '">'
                          + '<i class="fa fa-search"></i> Cari "' + q.replace(/[<>&"]/g, '') + '" di daftar pelanggan'
                          + '</a>';
                    },
                    error: function () {
                        searchResults.innerHTML = '<div style="padding:16px;color:#dc3545;font-size:12px;">Gagal memuat hasil.</div>';
                    }
                });
            }, 350);
        });
    }

    // ---------- Server clock ----------
    const clockEl = document.getElementById('servertime');
    if (clockEl) {
        const parts = clockEl.textContent.trim().split(':').map(Number);
        const base = new Date();
        base.setHours(parts[0] || 0, parts[1] || 0, parts[2] || 0);
        const diff = Date.now() - base.getTime();
        const pad = (n) => String(n).padStart(2, '0');
        const tick = () => {
            const now = new Date(Date.now() - diff);
            clockEl.textContent = pad(now.getHours()) + ':' + pad(now.getMinutes()) + ':' + pad(now.getSeconds());
        };
        tick();
        setInterval(tick, 1000);
    }

    // ---------- Auto-close mobile sidebar saat resize ke desktop ----------
    window.addEventListener('resize', function () {
        if (!isMobile() && body.classList.contains('rl-mobile-open')) {
            body.classList.remove('rl-mobile-open');
            overlay.classList.remove('rl-show');
        }
    });

})();
</script>

{if $_c['new_version_notify'] != 'disable'}
<script>
    window.addEventListener('DOMContentLoaded', function () {
        $.getJSON("./version.json?" + Math.random(), function (data) {
            var localVersion = data.version;
            $('#version').html('Version: ' + localVersion);
            $.getJSON(
                "https://raw.githubusercontent.com/hotspotbilling/phpnuxbill/master/version.json?" + Math.random(),
                function (data) {
                    var latestVersion = data.version;
                    if (localVersion !== latestVersion) {
                        $('#version').html('Latest Version: ' + latestVersion);
                        if (getCookie(latestVersion) != 'done') {
                            Swal.fire({
                                icon: 'info',
                                title: 'New Version Available',
                                html: 'Version: <strong>' + latestVersion + '</strong>',
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: true,
                                showCloseButton: true,
                                timer: 30000,
                                confirmButtonText: '<a href="{Text::url('community')}#latestVersion" style="color:#fff;text-decoration:none;">Update Now</a>',
                                timerProgressBar: true,
                                didOpen: (toast) => {
                                    toast.addEventListener('mouseenter', Swal.stopTimer);
                                    toast.addEventListener('mouseleave', Swal.resumeTimer);
                                }
                            });
                            setCookie(latestVersion, 'done', 7);
                        }
                    }
                }
            );
        });
    });
	
	
// Normalisasi menu plugin: paksa class rl-sub-link ke semua <a> di submenu
document.querySelectorAll('#rlNav .rl-submenu a').forEach(function (a) {
    if (!a.classList.contains('rl-sub-link')) {
        a.classList.add('rl-sub-link');
    }
    a.classList.remove('nav-link', 'dropdown-item');
});

document.querySelectorAll('#rlNav .rl-submenu li').forEach(function (li) {
    li.classList.remove('nav-item');
});	

// ==== NORMALISASI MENU PLUGIN ====
(function () {
    const sidebar = document.getElementById('rlSidebar');
    if (!sidebar) return;

    // 1. Tambahkan class top-level ke <li> yang belum punya
    sidebar.querySelectorAll('#rlNav > li').forEach(function (li) {
        if (!li.classList.contains('rl-nav-item')) {
            li.classList.add('rl-nav-item');
        }
        li.classList.remove('nav-item', 'treeview', 'dropdown');
    });

    // 2. Tambahkan class ke <a> — bedakan top level vs submenu
    sidebar.querySelectorAll('#rlNav a').forEach(function (a) {
        const inSub = a.closest('ul ul') !== null
                   || a.closest('.rl-submenu') !== null
                   || a.closest('.treeview-menu') !== null;

        if (inSub) {
            a.classList.add('rl-sub-link');
        } else {
            a.classList.add('rl-nav-link');
        }

        // Bersihkan class lama yang bentrok
        a.classList.remove('nav-link', 'dropdown-item', 'dropdown-toggle', 'menu-toggle');
    });

    // 3. Bungkus <i>/teks liar yang tidak dibungkus <li><a>
    sidebar.querySelectorAll('#rlNav > ul, #rlNav .rl-submenu').forEach(function (ul) {
        Array.from(ul.childNodes).forEach(function (node) {
            if (node.nodeType === 1 && node.tagName !== 'LI' && node.tagName !== 'UL') {
                const li = document.createElement('li');
                const a  = document.createElement('a');
                a.className = 'rl-nav-link';
                a.href = 'javascript:void(0);';
                a.appendChild(node.cloneNode(true));
                li.appendChild(a);
                ul.replaceChild(li, node);
            }
        });
    });

    // 4. Aktifkan accordion untuk menu plugin yang pakai treeview lama
    sidebar.querySelectorAll('#rlNav li').forEach(function (li) {
        const sub = li.querySelector(':scope > ul');
        if (!sub) return;

        const link = li.querySelector(':scope > a');
        if (!link) return;

        // Kalau link utama punya href="javascript:void(0);" atau "#" → jadikan toggle
        const href = link.getAttribute('href') || '';
        if (href === '' || href === '#' || href.indexOf('javascript:void') === 0) {
            link.addEventListener('click', function (e) {
                e.preventDefault();
                const isOpen = li.classList.contains('rl-open');
                // tutup sibling
                li.parentElement.querySelectorAll(':scope > li.rl-open').forEach(function (other) {
                    if (other !== li) other.classList.remove('rl-open');
                });
                li.classList.toggle('rl-open', !isOpen);
            });
        }
    });
})();
</script>
{/if}
</body>
</html>